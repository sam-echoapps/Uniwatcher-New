export { RatingGauge } from './rating-gauge';
export { CRatingGaugeElement } from './rating-gauge';