import 'oj-c/button';
declare const _default: () => import("preact").JSX.Element;
export default _default;
