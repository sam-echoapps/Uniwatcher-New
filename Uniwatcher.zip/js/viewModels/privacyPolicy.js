'use strict';
define(['ojs/ojcore', 'knockout', 'jquery', 'appController', 'ojs/ojarraydataprovider', 
    'ojs/ojknockout','ojs/ojcheckboxset','ojs/ojinputtext',
    'ojs/ojbutton',"ojs/ojprogress-circle", 'ojs/ojdatetimepicker','ojs/ojvalidationgroup',
    'ojs/ojselectsingle','ojs/ojformlayout','ojs/ojdialog',"ojs/ojpopup"],
    function(oj, ko, $, app, ArrayDataProvider) {
        class privacyPolicy {
            constructor() {
                var self = this;
                
               
            
            }
        }
        return privacyPolicy;
    }
);
